import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Code, Users, BookOpen, Award } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold">
              R
            </div>
            <span className="font-bold text-lg hidden sm:inline">RDSLP</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-medium hover:text-primary transition-colors">Sobre el Proyecto</a>
            <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">Características</a>
            <a href="#team" className="text-sm font-medium hover:text-primary transition-colors">Equipo</a>
            <a href="#details" className="text-sm font-medium hover:text-primary transition-colors">Detalles</a>
          </nav>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <Button variant="outline" size="sm" onClick={logout}>
                Cerrar Sesión
              </Button>
            ) : (
              <Button size="sm" onClick={() => window.location.href = getLoginUrl()}>
                Iniciar Sesión
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 sm:py-32">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10" />
          <div className="container relative">
            <div className="max-w-2xl">
              <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
                RDSLP
              </h1>
              <p className="text-xl text-muted-foreground mb-2 font-semibold">
                Red Social de Lenguajes de Programación y Lógica de Programación
              </p>
              <p className="text-lg text-muted-foreground mb-8">
                Una plataforma web innovadora orientada a la educación en lógica de programación y lenguajes de programación, diseñada para estudiantes y desarrolladores.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="w-full sm:w-auto">
                  Explorar Plataforma
                </Button>
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Aprender Más
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 bg-muted/30">
          <div className="container">
            <div className="max-w-3xl">
              <h2 className="text-3xl font-bold mb-6">Sobre el Proyecto</h2>
              <p className="text-lg text-muted-foreground mb-6">
                RDSLP es una plataforma educativa integral que proporciona recursos, herramientas y comunidad para aprender y dominar los fundamentos de la lógica de programación y diversos lenguajes de programación.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                Nuestro objetivo es democratizar la educación en programación, ofreciendo una experiencia de aprendizaje interactiva y colaborativa que permita a los estudiantes desarrollar habilidades sólidas en pensamiento lógico y desarrollo de software.
              </p>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12">Características Principales</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <Code className="w-8 h-8 text-primary mb-2" />
                  <CardTitle>Múltiples Lenguajes</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Aprende Python, JavaScript, Java, C++ y más lenguajes de programación
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <BookOpen className="w-8 h-8 text-primary mb-2" />
                  <CardTitle>Contenido Educativo</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Tutoriales, ejercicios y proyectos prácticos para fortalecer tu aprendizaje
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Users className="w-8 h-8 text-primary mb-2" />
                  <CardTitle>Comunidad Activa</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Conecta con otros estudiantes, comparte conocimientos y colabora en proyectos
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Award className="w-8 h-8 text-primary mb-2" />
                  <CardTitle>Certificaciones</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Obtén certificados al completar cursos y demostraciones de competencia
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section id="team" className="py-20 bg-muted/30">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12">Equipo del Proyecto</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                    <Users className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle>Ricardo Jaraba Gallego</CardTitle>
                  <CardDescription>Desarrollador Principal</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Líder del proyecto RDSLP, especializado en educación en programación y desarrollo de plataformas educativas.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Academic Details Section */}
        <section id="details" className="py-20">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12">Detalles Académicos</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Asignatura</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg font-semibold text-primary mb-2">Lenguajes de Programación y POO</p>
                  <p className="text-muted-foreground">
                    Este proyecto forma parte de la asignatura de Lenguajes de Programación y Programación Orientada a Objetos.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Modalidad</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg font-semibold text-primary mb-2">Prototipo</p>
                  <p className="text-muted-foreground">
                    RDSLP se presenta como un prototipo funcional que demuestra los conceptos fundamentales de una plataforma educativa moderna.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-6">¿Listo para Comenzar?</h2>
            <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
              Únete a nuestra comunidad de aprendizaje y comienza tu viaje en el mundo de la programación.
            </p>
            <Button size="lg" variant="secondary" className="w-full sm:w-auto">
              Acceder a la Plataforma
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">RDSLP</h3>
              <p className="text-sm text-muted-foreground">
                Plataforma educativa para lenguajes de programación y lógica de programación.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Proyecto</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#about" className="hover:text-primary transition-colors">Sobre Nosotros</a></li>
                <li><a href="#features" className="hover:text-primary transition-colors">Características</a></li>
                <li><a href="#team" className="hover:text-primary transition-colors">Equipo</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Académico</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Lenguajes de Programación y POO</li>
                <li>Modalidad: Prototipo</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contacto</h4>
              <p className="text-sm text-muted-foreground">
                Ricardo Jaraba Gallego<br />
                Desarrollador Principal
              </p>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 RDSLP. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
